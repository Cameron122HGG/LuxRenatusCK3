version="1.18"
tags={
	"Graphics"
	"Religion"
	"Culture"
}
name="Lux Renata Emblems Extended"
supported_version="1.18.2"
path="mod/lux_renata_emblems_extended"